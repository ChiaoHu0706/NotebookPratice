package FormPratice1;

import javax.swing.JFrame;

public class Pratice_Make_Form {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame Win=new JFrame();
		Win.setBounds(500,500,400,200);
		Win.setTitle("Hello Form ! ! !");
		Win.setVisible(true);
		Win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
